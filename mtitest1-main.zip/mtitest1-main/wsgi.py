from app import app
application = app
